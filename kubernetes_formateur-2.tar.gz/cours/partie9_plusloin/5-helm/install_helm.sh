#!/usr/bin/env bash

# Script permettant d'installer helm
# version Baranger du 31/01/2023

# Variables
TITLE_COLOR="\033[0;33m"
CMD_COLOR="\033[0;32m"
NC="\033[0m"
masters_list="master"
postes_list="admin"
log_file="/var/log/install_helm.log"
helm_url="https://get.helm.sh/helm-v3.2.1-linux-amd64.tar.gz"
helm_tmp_tar="/tmp/helm.tar.gz"
helm_tmp_binary="/tmp/linux-amd64/helm"

# Test script lancé en root
if [ "$UID" -ne 0 ]; then
    echo "Le script $0 doit être lancé en tant que root"
    exit 1
fi

# Installation de Helm sur $masters_list
echo -e "${TITLE_COLOR}Installation de Helm sur $masters_list${NC}"
echo -e "\t=> Recuperation de l'archive tar"
cmd="wget ${helm_url} -O ${helm_tmp_tar}"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done
echo -e "\t=> Decompression de l'archive"
cmd="tar xfvz ${helm_tmp_tar} -C /tmp"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done
echo -e "\t=> Copie du binaire dans /usr/local/bin"
cmd="cp ${helm_tmp_binary} /usr/local/bin"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done

# Installation de Helm sur $postes_list
echo -e "\n${TITLE_COLOR}Installation de Helm sur $postes_list${NC}"
echo -e "\t=> Recuperation de l'archive tar"
cmd="wget ${helm_url} -O ${helm_tmp_tar}"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $postes_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done
echo -e "\t=> Decompression de l'archive"
cmd="tar xfvz ${helm_tmp_tar} -C /tmp"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $postes_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done
echo -e "\t=> Copie du binaire dans /usr/local/bin"
cmd="cp ${helm_tmp_binary} /usr/local/bin"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $postes_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done

