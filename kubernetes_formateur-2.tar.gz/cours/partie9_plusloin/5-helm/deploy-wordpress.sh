#!/usr/bin/env bash

# Script permettant d'installer un site wordpress a partir de helm
# version de Baranger du 31/01/2023

# Variables
TITLE_COLOR="\033[0;33m"
CMD_COLOR="\033[0;32m"
NC="\033[0m"
#files_rep="/srv/git/formation-kubernetes/demos"
files_rep="."
workers_list="worker1 worker2"
masters_list="master"
network_nodes="192.168.56.0/24"
all_list="$masters_list $workers_list"
log_file="/var/log/install_wordpress.log"
kubernetes_paquets="kubelet kubeadm kubectl"
pv_wordpress_file="${files_rep}/pv-wordpress.yml"
pv_wordpress_bdd_file="${files_rep}/pv-bdd-wordpress.yml"
pvc_wordpress_file="${files_rep}/pvc-wordpress.yml"
kubectl_user="user1"
nodeport_cmd='kubectl get --namespace wordpress -o jsonpath="{.spec.ports[0].nodePort}" services my-wordpress'
nodeip_cmd='kubectl get nodes --namespace wordpress -o jsonpath="{.items[0].status.addresses[0].address}"'
password_cmd='kubectl get secret --namespace wordpress my-wordpress -o jsonpath="{.data.wordpress-password}" | base64 --decode'

# Installation de Helm
echo -e "${TITLE_COLOR}Deploiement d'un site Wordpress a partir du chart de bitnami${NC}"

# Test script lancé en root
if [ "$UID" -ne 0 ]; then
    echo "Le script $0 doit être lancé en tant que root"
    exit 1
fi

# Nettoyage
echo -e "\t=> Nettoyage"
cmd="rm -rf /srv/wordpress"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $workers_list; do
    ssh ${i} "$cmd > /dev/null 2>&1"
done
cmd="kubectl delete ns wordpress"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd > /dev/null 2>&1"
done
cmd="kubectl delete pv pv-wordpress"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd > /dev/null 2>&1"
done
cmd="kubectl delete pv pv-bdd-wordpress"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd > /dev/null 2>&1"
done
cmd="rm -rf /tmp/wordpress"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "$cmd > /dev/null 2>&1"
done

# Deploiement
echo -e "\t=> Ajout du repo de bitnami"
cmd="/usr/local/bin/helm repo add bitnami https://charts.bitnami.com/bitnami"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Changement des droits sur le fichier de logs"
cmd="chown ${kubectl_user}:${kubectl_user} $log_file"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done
echo -e "\t=> Creation du Namespace wordpress"
cmd="kubectl create ns wordpress"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Creation du pv wordpress"
cmd="kubectl apply -f $pv_wordpress_file"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Creation du pv wordpress-bdd"
cmd="kubectl apply -f $pv_wordpress_bdd_file"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Creation du pvc wordpress"
cmd="kubectl apply -f $pvc_wordpress_file"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Creation du repertoire /srv/wordpress/app/wordpress"
cmd="mkdir -p /srv/wordpress/app/wordpress"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $workers_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done
echo -e "\t=> Creation du repertoire /srv/wordpress/bdd"
cmd="mkdir -p /srv/wordpress/bdd"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $workers_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done
echo -e "\t=> Mise en place des bons droits pour le repertoire /srv/wordpress"
cmd="chown -R 1001:1001 /srv/wordpress"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $workers_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done
echo -e "\t=> Pull du chart wordpress"
cmd="/usr/local/bin/helm pull --untar bitnami/wordpress --untardir /tmp"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Modification du service LoadBalancer en NodePort dans le fichier de configuration"
cmd="sed -i 's/type: LoadBalancer/type: NodePort/' /tmp/wordpress/values.yaml"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done
echo -e "\t=> Ajout de notre PersistentVolumeClaim dans le fichier de configuration"
cmd="sed -i 's/existingClaim: \"\"/existingClaim: pvc-wordpress/' /tmp/wordpress/values.yaml"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done
echo -e "\t=> Installation du chart"
cmd="/usr/local/bin/helm install -f /tmp/wordpress/values.yaml --namespace wordpress my-wordpress bitnami/wordpress"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
sleep 30
cmd="chown -R 1001:1001 /srv/wordpress"
for i in $workers_list; do
    ssh ${i} "$cmd >> $log_file 2>&1"
done
echo -e "\t=> Recuperation du port"
echo -e "\t\t${CMD_COLOR}${nodeport_cmd}${NC}"
for i in $masters_list; do
    nodeport=$(ssh ${i} "sudo -u $kubectl_user $nodeport_cmd")
done
echo -e "\t=> Recuperation de l'adresse IP"
echo -e "\t\t${CMD_COLOR}${nodeip_cmd}${NC}"
for i in $masters_list; do
    nodeip=$(ssh ${i} "sudo -u $kubectl_user $nodeip_cmd")
done
echo -e "\t=> Recuperation du mot de passe"
echo -e "\t\t${CMD_COLOR}${password_cmd}${NC}"
for i in $masters_list; do
    password=$(ssh ${i} "sudo -u $kubectl_user $password_cmd")
done
echo -e "\t=> Attente de la fin du deploiement (1 minute)"
sleep 60
echo -e "\t=> Site Wordpress accessible :"
echo -e "\t\t- Url : http://$nodeip:$nodeport"
echo -e "\t\t- Admin Url : http://$nodeip:$nodeport/admin"
echo -e "\t\t- Admin User : user"
echo -e "\t\t- Admin Password : $password"
