#!/usr/bin/env bash

# Script permettant d'installer le dashboard Kubernetes

# Variables
TITLE_COLOR="\033[0;33m"
CMD_COLOR="\033[0;32m"
NC="\033[0m"
files_rep="/srv/git/formation-kubernetes/demos"
workers_list="worker1 worker2"
masters_list="master"
network_nodes="192.168.56.0/24"
all_list="$masters_list $workers_list"
log_file="/var/log/install_dashboard.log"
kubernetes_paquets="kubelet kubeadm kubectl"
kubernetes_user=user1
dash_manifest="${files_rep}/dash.yml"
sa_manifest="${files_rep}/sa-admin.yml"
rbac_manifest="${files_rep}/rbac-admin.yml"
token_manifest="${files_rep}/token.yml"
kubectl_user="user1"
token_path_cmd="kubectl describe sa dash-admin -n kube-system | awk '\$1 ~ /^Tokens:/ {print \$2}'"
port_cmd="kubectl get svc -n kubernetes-dashboard | awk '\$1 ~ /^kubernetes-dashboard/ {print \$5}'"
master_ip=192.168.56.31

# Installation du dashboard
echo -e "${TITLE_COLOR}Installation du dashboard Kubernetes${NC}"

# Test script lancé en root
if [ "$UID" -ne 0 ]; then
    echo "Le script $0 doit être lancé en tant que root"
    exit 1
fi

# Nettoyage
echo -e "\t=> Nettoyage"
cmd="kubectl delete ns kubernetes-dashboard"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd > /dev/null 2>&1"
done
cmd="kubectl delete sa sa-admin -n kube-system"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd > /dev/null 2>&1"
done

# Deploiement
echo -e "\t=> Application du fichier Manifest récupéré et modifié (ajout du type NodePort)"
cmd="kubectl apply -f $dash_manifest"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Mise en place du ClusterRoleBinding"
cmd="kubectl apply -f $rbac_manifest"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Mise en place du secret (Token)"
cmd="kubectl apply -f $token_manifest"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Recuperation du token"
token_cmd="kubectl describe -n kubernetes-dashboard secret token | awk '\$1 ~ /^token:$/ {print \$2}'"
echo -e "\t\t${CMD_COLOR}${token_cmd}${NC}"
for i in $masters_list; do
    token=$(ssh ${i} "sudo -u $kubectl_user $token_cmd")
done
echo -e "\t=> Recuperation du port"
echo -e "\t\t${CMD_COLOR}${port_cmd}${NC}"
for i in $masters_list; do
    port=$(ssh ${i} "sudo -u $kubectl_user $port_cmd")
    port=${port%%/*}
    port=${port##*:}
done
echo -e "\t=> Dashboard accessible :"
echo -e "\t\t- Url : https://$master_ip:$port"
echo -e "\t\t- Token : $token"
