#!/usr/bin/env bash

# Script permettant d'installer un site wordpress a partir de helm

# Variables
TITLE_COLOR="\033[0;33m"
CMD_COLOR="\033[0;32m"
NC="\033[0m"
files_rep="/srv/git/formation-kubernetes/demos"
workers_list="worker1 worker2"
masters_list="master"
network_nodes="192.168.56.0/24"
all_list="$masters_list $workers_list"
log_file="/var/log/install_grafana.log"
kubernetes_paquets="kubelet kubeadm kubectl"
kubectl_user=user1
prometheus_manifest="${files_rep}/svc-prometheus.yml"
grafana_manifest="${files_rep}/svc-grafana.yml"
port_grafana_cmd="kubectl get svc -n monitoring | awk '\$1 ~ /^svc-grafana/ {print \$5}'"
port_prometheus_cmd="kubectl get svc -n monitoring | awk '\$1 ~ /^svc-prometheus/ {print \$5}'"
master_ip=192.168.56.31

# Déploiement de la stack
echo -e "${TITLE_COLOR}Deploiement de la stack Prometheus/Grafana${NC}"

# Test script lancé en root
if [ "$UID" -ne 0 ]; then
    echo "Le script $0 doit être lancé en tant que root"
    exit 1
fi

# Nettoyage
echo -e "\t=> Nettoyage"
cmd="kubectl delete ns monitoring"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd > /dev/null 2>&1"
done

# Deploiement
echo -e "\t=> Ajout du repo stable"
cmd="/usr/local/bin/helm repo add stable https://charts.helm.sh/stable"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Ajout du repo de la communaute Prometheus"
cmd="/usr/local/bin/helm repo add prometheus-community https://prometheus-community.github.io/helm-charts"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Mise a jour de helm"
cmd="/usr/local/bin/helm repo update"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Creation du namespace monitoring"
cmd="kubectl create ns monitoring"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Installation du chart"
cmd="/usr/local/bin/helm install my-monitor prometheus-community/kube-prometheus-stack --namespace=monitoring"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
sleep 30
echo -e "\t=> Mise en place du service pour prometheus"
cmd="kubectl apply -f $prometheus_manifest"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Mise en place du service pour grafana"
cmd="kubectl apply -f $grafana_manifest"
echo -e "\t\t${CMD_COLOR}${cmd}${NC}"
for i in $masters_list; do
    ssh ${i} "sudo -u $kubectl_user $cmd >> $log_file 2>&1"
done
echo -e "\t=> Recuperation du port de prometheus"
echo -e "\t\t${CMD_COLOR}${port_prometheus_cmd}${NC}"
for i in $masters_list; do
    port_prometheus=$(ssh ${i} "sudo -u $kubectl_user $port_prometheus_cmd")
    port_prometheus=${port_prometheus%%/*}
    port_prometheus=${port_prometheus##*:}
done
echo -e "\t=> Recuperation du port de grafana"
echo -e "\t\t${CMD_COLOR}${port_grafana_cmd}${NC}"
for i in $masters_list; do
    port_grafana=$(ssh ${i} "sudo -u $kubectl_user $port_grafana_cmd")
    port_grafana=${port_grafana%%/*}
    port_grafana=${port_grafana##*:}
done
echo -e "\t=> Prometheus :"
echo -e "\t\t- Url : http://$master_ip:$port_prometheus"
echo -e "\t=> grafana :"
echo -e "\t\t- Url : http://$master_ip:$port_grafana"
echo -e "\t\t- User : admin"
echo -e "\t\t- password : prom-operator"
