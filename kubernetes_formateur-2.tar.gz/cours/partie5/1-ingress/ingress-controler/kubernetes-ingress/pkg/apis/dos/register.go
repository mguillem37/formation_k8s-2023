package dos

const (
	// GroupName the name of the group used by kubernetes.
	GroupName = "appprotectdos.f5.com"
)
