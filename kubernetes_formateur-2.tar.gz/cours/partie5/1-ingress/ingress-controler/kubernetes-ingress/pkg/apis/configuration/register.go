package configuration

const (
	// GroupName is the name of the group.
	GroupName = "k8s.nginx.org"
)
