// Package validation provides validation rules for the ExternalDNS CRD.
package validation
